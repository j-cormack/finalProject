//
//  finalProjectApp.swift
//  finalProject
//
//  Created by Jess Cormack on 14/07/2023.
//

import SwiftUI

@main
struct finalProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
